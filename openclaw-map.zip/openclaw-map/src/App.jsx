import React, { useState, useRef, useEffect } from 'react';

const concepts = {
  gateway: {
    title: "GATEWAY",
    icon: "🚪",
    color: "#00F0FF",
    desc: "Central daemon. WebSocket control plane ws://127.0.0.1:18789",
    points: ["Baileys WhatsApp", "JSON protocol", "Single instance"],
    tier: "CORE"
  },
  agents: {
    title: "AGENT RUNTIME",
    icon: "🤖",
    color: "#FF00E5",
    desc: "Pi agent execution. Workspace: AGENTS.md, SOUL.md, TOOLS.md",
    points: ["Pi coding agent", "Context injection", "Tool orchestration"],
    tier: "CORE"
  },
  agentLoop: {
    title: "AGENT LOOP",
    icon: "🔄",
    color: "#FF3366",
    desc: "Cycle: intake → context → inference → tools → stream → persist",
    points: ["Session serialization", "Hook system", "Auto-compact"],
    tier: "PROC"
  },
  sessions: {
    title: "SESSIONS",
    icon: "💬",
    color: "#00FF94",
    desc: "Isolated conversations. Key=bucket, ID=transcript file",
    points: ["DM/Group isolation", "Daily reset 04:00", "Identity linking"],
    tier: "DATA"
  },
  context: {
    title: "CONTEXT",
    icon: "📋",
    color: "#FFD000",
    desc: "System prompt + history + tool calls. Window-limited",
    points: ["Bootstrap inject", "Skills manifest", "Schema overhead"],
    tier: "DATA"
  },
  memory: {
    title: "MEMORY",
    icon: "🧠",
    color: "#FF4444",
    desc: "MEMORY.md + daily logs. Vector+BM25 SQLite search",
    points: ["sqlite-vec embed", "Pre-compact flush", "Auto reindex"],
    tier: "DATA"
  },
  channels: {
    title: "CHANNELS",
    icon: "📱",
    color: "#00DDFF",
    desc: "WhatsApp, Telegram, Discord, Slack, iMessage bridges",
    points: ["Baileys/grammY", "DM policies", "Chunk routing"],
    tier: "INPUT"
  },
  tools: {
    title: "TOOLS+SKILLS",
    icon: "🔧",
    color: "#AAFF00",
    desc: "FS, shell, browser, web, memory. On-demand skills",
    points: ["Group policies", "Allow/deny ACL", "Elevated exec"],
    tier: "EXEC"
  },
  routing: {
    title: "MULTI-AGENT",
    icon: "🔀",
    color: "#DD66FF",
    desc: "Multiple agents with binding-based routing",
    points: ["Isolated workspaces", "Per-agent auth", "Sub-agents"],
    tier: "CORE"
  },
  streaming: {
    title: "STREAMING",
    icon: "📡",
    color: "#FF8800",
    desc: "Block streaming, draft mode, typing indicators",
    points: ["800-1200 chunks", "Typing modes", "Reasoning out"],
    tier: "PROC"
  },
  compaction: {
    title: "COMPACTION",
    icon: "📦",
    color: "#00FFCC",
    desc: "Overflow summarization. Result pruning",
    points: ["20k token reserve", "Soft/hard trim", "Cache TTL"],
    tier: "PROC"
  },
  models: {
    title: "MODELS",
    icon: "🎯",
    color: "#8866FF",
    desc: "Anthropic, OpenAI, OpenRouter. Auto-failover",
    points: ["Fallback chain", "Profile pinning", "Cooldown backoff"],
    tier: "EXEC"
  },
  security: {
    title: "SECURITY",
    icon: "🔒",
    color: "#FF2266",
    desc: "DM policy, sandbox isolation, tool policy",
    points: ["Container sandbox", "Audit command", "Opus 4.5 rec"],
    tier: "EXEC"
  },
  workspace: {
    title: "WORKSPACE",
    icon: "📁",
    color: "#888899",
    desc: "~/.openclaw/workspace — agent working directory",
    points: ["Bootstrap files", "skills/ folder", "Git backup"],
    tier: "DATA"
  }
};

const layout = {
  channels: { x: 70, y: 50 },
  gateway: { x: 290, y: 50 },
  routing: { x: 510, y: 50 },
  agentLoop: { x: 110, y: 170 },
  agents: { x: 290, y: 170 },
  sessions: { x: 470, y: 170 },
  context: { x: 70, y: 290 },
  tools: { x: 220, y: 290 },
  memory: { x: 370, y: 290 },
  workspace: { x: 520, y: 290 },
  streaming: { x: 70, y: 410 },
  compaction: { x: 220, y: 410 },
  models: { x: 370, y: 410 },
  security: { x: 520, y: 410 },
};

const links = [
  ['channels', 'gateway', true],
  ['gateway', 'routing'],
  ['gateway', 'agents'],
  ['gateway', 'sessions'],
  ['agents', 'agentLoop'],
  ['agentLoop', 'context'],
  ['agentLoop', 'streaming'],
  ['agents', 'tools'],
  ['agents', 'workspace'],
  ['tools', 'security'],
  ['sessions', 'memory'],
  ['sessions', 'compaction'],
  ['memory', 'workspace'],
  ['context', 'tools'],
  ['context', 'memory'],
  ['compaction', 'models'],
  ['compaction', 'memory'],
  ['routing', 'agents'],
  ['routing', 'sessions'],
  ['security', 'workspace'],
];

const W = 130, H = 52;

const tierStyle = {
  CORE: { bg: 'from-blue-500/20 to-purple-500/10', ring: 'ring-blue-500/50' },
  INPUT: { bg: 'from-cyan-500/20 to-cyan-500/5', ring: 'ring-cyan-500/50' },
  PROC: { bg: 'from-pink-500/20 to-orange-500/10', ring: 'ring-pink-500/50' },
  DATA: { bg: 'from-emerald-500/20 to-yellow-500/10', ring: 'ring-emerald-500/50' },
  EXEC: { bg: 'from-violet-500/20 to-rose-500/10', ring: 'ring-violet-500/50' },
};

export default function OpenClawMap() {
  const [pos, setPos] = useState(layout);
  const [sel, setSel] = useState(null);
  const [drag, setDrag] = useState(null);
  const [off, setOff] = useState({ x: 0, y: 0 });
  const [time, setTime] = useState(0);
  const svgRef = useRef(null);

  useEffect(() => {
    const t = setInterval(() => setTime(p => p + 1), 50);
    return () => clearInterval(t);
  }, []);

  const onDown = (e, id) => {
    e.stopPropagation();
    const r = svgRef.current.getBoundingClientRect();
    setDrag(id);
    setOff({ x: e.clientX - r.left - pos[id].x, y: e.clientY - r.top - pos[id].y });
  };

  useEffect(() => {
    if (!drag) return;
    const move = (e) => {
      const r = svgRef.current.getBoundingClientRect();
      setPos(p => ({
        ...p,
        [drag]: {
          x: Math.max(5, Math.min(e.clientX - r.left - off.x, 680 - W)),
          y: Math.max(5, Math.min(e.clientY - r.top - off.y, 490 - H))
        }
      }));
    };
    const up = () => setDrag(null);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [drag, off]);

  const path = (a, b) => {
    const p1 = pos[a], p2 = pos[b];
    const x1 = p1.x + W/2, y1 = p1.y + H/2;
    const x2 = p2.x + W/2, y2 = p2.y + H/2;
    const my = (y1 + y2) / 2;
    return `M${x1},${y1} C${x1},${my} ${x2},${my} ${x2},${y2}`;
  };

  const data = sel ? concepts[sel] : null;
  const conns = sel ? links.filter(l => l[0] === sel || l[1] === sel).map(l => l[0] === sel ? l[1] : l[0]) : [];

  return (
    <div className="min-h-screen bg-[#05060a] text-white overflow-hidden relative font-mono">
      {/* Scanlines overlay */}
      <div 
        className="pointer-events-none fixed inset-0 z-50 opacity-[0.03]"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,255,0.03) 2px, rgba(0,255,255,0.03) 4px)'
        }}
      />
      
      {/* Grid background */}
      <div 
        className="fixed inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,240,255,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,240,255,0.03) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px'
        }}
      />

      {/* Ambient glow */}
      <div className="fixed top-1/4 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-[100px]" />
      <div className="fixed bottom-1/4 right-1/3 w-80 h-80 bg-fuchsia-500/5 rounded-full blur-[100px]" />

      <div className="relative z-10 flex flex-col lg:flex-row min-h-screen">
        {/* Main viewport */}
        <div className="flex-1 p-4 lg:p-6">
          {/* Header */}
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="text-4xl">🦞</div>
                <div 
                  className="absolute inset-0 blur-lg opacity-50"
                  style={{ 
                    background: 'radial-gradient(circle, #00F0FF 0%, transparent 70%)',
                    animation: 'pulse 2s infinite'
                  }}
                />
              </div>
              <div>
                <h1 
                  className="text-2xl lg:text-3xl font-bold tracking-[0.2em] uppercase"
                  style={{ 
                    fontFamily: "'Orbitron', 'Audiowide', sans-serif",
                    textShadow: '0 0 20px rgba(0,240,255,0.5), 0 0 40px rgba(0,240,255,0.2)'
                  }}
                >
                  <span className="text-cyan-400">Open</span>
                  <span className="text-fuchsia-400">Claw</span>
                </h1>
                <div className="flex items-center gap-2 mt-1">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-[10px] tracking-[0.3em] text-slate-500 uppercase">
                    System Architecture v2.0
                  </span>
                </div>
              </div>
            </div>
            
            <div className="hidden lg:flex items-center gap-4 text-[10px] text-slate-500">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-pulse" />
                <span>NODES: {Object.keys(concepts).length}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-fuchsia-400 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }} />
                <span>LINKS: {links.length}</span>
              </div>
            </div>
          </div>

          {/* Graph viewport */}
          <div 
            className="relative rounded-lg overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, rgba(5,6,10,0.9) 0%, rgba(10,15,25,0.95) 100%)',
              boxShadow: 'inset 0 0 60px rgba(0,240,255,0.03), 0 0 0 1px rgba(0,240,255,0.1)',
            }}
          >
            {/* Corner decorations */}
            {['top-0 left-0', 'top-0 right-0 rotate-90', 'bottom-0 right-0 rotate-180', 'bottom-0 left-0 -rotate-90'].map((pos, i) => (
              <div key={i} className={`absolute ${pos} w-8 h-8 pointer-events-none`}>
                <svg viewBox="0 0 32 32" className="w-full h-full text-cyan-500/30">
                  <path d="M0 8 L0 0 L8 0" fill="none" stroke="currentColor" strokeWidth="1"/>
                  <path d="M0 4 L4 4 L4 0" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.5"/>
                </svg>
              </div>
            ))}

            <svg 
              ref={svgRef}
              className="w-full"
              style={{ height: 'calc(100vh - 180px)', minHeight: '500px' }}
              viewBox="0 0 680 500"
              preserveAspectRatio="xMidYMid meet"
            >
              <defs>
                {/* Glow filters */}
                {Object.entries(concepts).map(([id, c]) => (
                  <filter key={id} id={`glow-${id}`} x="-100%" y="-100%" width="300%" height="300%">
                    <feGaussianBlur stdDeviation="6" result="blur"/>
                    <feFlood floodColor={c.color} floodOpacity="0.6"/>
                    <feComposite in2="blur" operator="in"/>
                    <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
                  </filter>
                ))}
                
                {/* Animated data flow */}
                <linearGradient id="dataFlow" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#00F0FF" stopOpacity="0">
                    <animate attributeName="offset" values="-0.5;1" dur="2s" repeatCount="indefinite"/>
                  </stop>
                  <stop offset="30%" stopColor="#00F0FF" stopOpacity="1">
                    <animate attributeName="offset" values="-0.2;1.3" dur="2s" repeatCount="indefinite"/>
                  </stop>
                  <stop offset="100%" stopColor="#FF00E5" stopOpacity="0">
                    <animate attributeName="offset" values="0.5;2" dur="2s" repeatCount="indefinite"/>
                  </stop>
                </linearGradient>
              </defs>

              {/* Links */}
              {links.map(([a, b, anim], i) => {
                const active = sel && (a === sel || b === sel);
                const c = active ? concepts[sel].color : '#1e293b';
                return (
                  <g key={i}>
                    {active && (
                      <path d={path(a, b)} fill="none" stroke={c} strokeWidth="8" opacity="0.15" strokeLinecap="round"/>
                    )}
                    <path 
                      d={path(a, b)} 
                      fill="none" 
                      stroke={anim && !sel ? 'url(#dataFlow)' : c}
                      strokeWidth={active ? 2 : 1}
                      strokeLinecap="round"
                      opacity={sel && !active ? 0.1 : 0.8}
                      className="transition-all duration-300"
                    />
                    {anim && !sel && (
                      <circle r="3" fill="#00F0FF">
                        <animateMotion dur="1.5s" repeatCount="indefinite" path={path(a, b)}/>
                      </circle>
                    )}
                  </g>
                );
              })}

              {/* Nodes */}
              {Object.entries(pos).map(([id, p]) => {
                const c = concepts[id];
                const isSel = sel === id;
                const isConn = conns.includes(id);
                const dim = sel && !isSel && !isConn;

                return (
                  <g
                    key={id}
                    transform={`translate(${p.x},${p.y})`}
                    onMouseDown={e => onDown(e, id)}
                    onClick={() => setSel(isSel ? null : id)}
                    style={{ cursor: drag === id ? 'grabbing' : 'pointer' }}
                    opacity={dim ? 0.2 : 1}
                    filter={isSel ? `url(#glow-${id})` : undefined}
                    className="transition-opacity duration-300"
                  >
                    {/* Outer ring pulse */}
                    {isSel && (
                      <rect
                        x="-4" y="-4" width={W+8} height={H+8} rx="10"
                        fill="none" stroke={c.color} strokeWidth="1"
                        opacity={0.3 + Math.sin(time * 0.15) * 0.2}
                      />
                    )}
                    
                    {/* Node body */}
                    <rect
                      width={W} height={H} rx="6"
                      fill={isSel ? c.color : '#0a0c12'}
                      fillOpacity={isSel ? 0.15 : 0.9}
                      stroke={c.color}
                      strokeWidth={isSel ? 2 : isConn ? 1.5 : 0.5}
                      strokeOpacity={isSel ? 1 : isConn ? 0.8 : 0.3}
                    />
                    
                    {/* Top highlight line */}
                    <rect x="4" y="1" width={W-8} height="1" rx="0.5" fill={c.color} opacity={0.3}/>

                    {/* Icon */}
                    <text x="16" y={H/2+5} fontSize="16" className="select-none pointer-events-none">
                      {c.icon}
                    </text>
                    
                    {/* Title */}
                    <text
                      x="36" y={H/2+4}
                      fill={isSel ? '#fff' : c.color}
                      fontSize="9"
                      fontWeight="600"
                      letterSpacing="1"
                      className="select-none pointer-events-none uppercase"
                    >
                      {c.title.length > 12 ? c.title.slice(0,11)+'…' : c.title}
                    </text>

                    {/* Tier badge */}
                    <rect x={W-28} y={H-14} width="24" height="10" rx="2" fill={c.color} fillOpacity="0.2"/>
                    <text x={W-16} y={H-6} fill={c.color} fontSize="5" textAnchor="middle" className="select-none pointer-events-none">
                      {c.tier}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Legend bar */}
            <div className="absolute bottom-3 left-3 flex flex-wrap gap-2">
              {[
                ['INPUT', '#00DDFF'], ['CORE', '#8866FF'], ['PROC', '#FF3366'], ['DATA', '#00FF94'], ['EXEC', '#AAFF00']
              ].map(([t, c]) => (
                <div key={t} className="flex items-center gap-1.5 px-2 py-1 rounded bg-black/50 border border-white/5">
                  <div className="w-2 h-2 rounded-sm" style={{ backgroundColor: c }}/>
                  <span className="text-[9px] tracking-widest text-slate-400">{t}</span>
                </div>
              ))}
            </div>

            {/* Timestamp */}
            <div className="absolute bottom-3 right-3 text-[9px] text-slate-600 font-mono">
              SYS.TIME: {new Date().toISOString().slice(11,19)}
            </div>
          </div>
        </div>

        {/* Details panel */}
        <div 
          className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l border-cyan-500/10"
          style={{ background: 'linear-gradient(180deg, rgba(5,6,10,0.98) 0%, rgba(10,12,20,0.98) 100%)' }}
        >
          <div className="p-5 h-full overflow-y-auto">
            {data ? (
              <div className="animate-fadeIn">
                {/* Header */}
                <div className="flex items-start gap-4 mb-5">
                  <div 
                    className="w-14 h-14 rounded-lg flex items-center justify-center text-2xl relative overflow-hidden"
                    style={{ 
                      background: `linear-gradient(135deg, ${data.color}20 0%, transparent 100%)`,
                      boxShadow: `0 0 30px ${data.color}20, inset 0 0 20px ${data.color}10`
                    }}
                  >
                    {data.icon}
                  </div>
                  <div className="flex-1">
                    <h2 
                      className="text-lg font-bold tracking-[0.15em] uppercase"
                      style={{ color: data.color, textShadow: `0 0 20px ${data.color}40` }}
                    >
                      {data.title}
                    </h2>
                    <div 
                      className={`inline-block mt-1.5 px-2 py-0.5 rounded text-[9px] tracking-[0.2em] uppercase border`}
                      style={{ borderColor: `${data.color}40`, color: data.color, background: `${data.color}10` }}
                    >
                      {data.tier} LAYER
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div 
                  className="mb-5 p-3 rounded border-l-2 bg-white/[0.02]"
                  style={{ borderColor: data.color }}
                >
                  <p className="text-slate-400 text-xs leading-relaxed">{data.desc}</p>
                </div>

                {/* Specs */}
                <div className="mb-5">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-1 h-1 rounded-full" style={{ backgroundColor: data.color }}/>
                    <span className="text-[9px] tracking-[0.3em] text-slate-500 uppercase">Specifications</span>
                    <div className="flex-1 h-px bg-gradient-to-r from-white/5 to-transparent"/>
                  </div>
                  <ul className="space-y-2">
                    {data.points.map((p, i) => (
                      <li key={i} className="flex items-center gap-3 group">
                        <div 
                          className="w-1 h-1 rounded-full transition-all group-hover:scale-150"
                          style={{ backgroundColor: data.color }}
                        />
                        <span className="text-slate-400 text-xs group-hover:text-white transition-colors">{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Connections */}
                {conns.length > 0 && (
                  <div className="mb-5">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-1 h-1 rounded-full bg-fuchsia-500"/>
                      <span className="text-[9px] tracking-[0.3em] text-slate-500 uppercase">Connections</span>
                      <div className="flex-1 h-px bg-gradient-to-r from-white/5 to-transparent"/>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {conns.map(id => {
                        const n = concepts[id];
                        return (
                          <button
                            key={id}
                            onClick={() => setSel(id)}
                            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[10px] uppercase tracking-wider transition-all hover:scale-105 border"
                            style={{ 
                              background: `${n.color}10`,
                              borderColor: `${n.color}30`,
                              color: n.color
                            }}
                          >
                            <span>{n.icon}</span>
                            <span>{n.title.split(' ')[0]}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                <button
                  onClick={() => setSel(null)}
                  className="w-full py-2.5 rounded text-xs uppercase tracking-[0.2em] transition-all border border-slate-700/50 bg-slate-800/30 hover:bg-slate-700/50 text-slate-400 hover:text-white"
                >
                  Close Panel
                </button>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-8">
                <div className="text-5xl mb-4 animate-float">🦞</div>
                <h2 
                  className="text-xl font-bold tracking-[0.2em] uppercase mb-1"
                  style={{ 
                    fontFamily: "'Orbitron', sans-serif",
                    background: 'linear-gradient(135deg, #00F0FF 0%, #FF00E5 100%)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent'
                  }}
                >
                  OpenClaw
                </h2>
                <p className="text-slate-500 text-xs mb-6 tracking-wider">
                  Personal AI Gateway System
                </p>
                
                <div className="w-full space-y-2">
                  {[
                    ['Gateway', 'ws://127.0.0.1:18789', '#00F0FF'],
                    ['Config', '~/.openclaw/openclaw.json', '#00FF94'],
                    ['Workspace', '~/.openclaw/workspace/', '#FFD000'],
                  ].map(([l, v, c]) => (
                    <div key={l} className="p-3 rounded border border-white/5 bg-white/[0.02] text-left group hover:border-white/10 transition-colors">
                      <div className="text-[9px] text-slate-500 uppercase tracking-[0.2em] mb-1">{l}</div>
                      <code className="text-[11px]" style={{ color: c }}>{v}</code>
                    </div>
                  ))}
                </div>

                <div className="mt-8 pt-5 border-t border-white/5 w-full flex justify-center gap-6 text-[10px]">
                  <a href="https://docs.openclaw.ai" target="_blank" className="text-slate-500 hover:text-cyan-400 transition-colors tracking-wider uppercase">
                    📚 Docs
                  </a>
                  <a href="https://github.com/openclaw/openclaw" target="_blank" className="text-slate-500 hover:text-fuchsia-400 transition-colors tracking-wider uppercase">
                    💻 Source
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>


    </div>
  );
}
